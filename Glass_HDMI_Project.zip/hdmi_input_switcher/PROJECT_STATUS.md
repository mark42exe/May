# Project status

- Stage: Source implementation prepared; APK build and device acceptance remain incomplete.
- Target: Acer Android TV, exact model/firmware not provided.
- Included: WebView glass UI, D-pad selection, long-press/Right HDMI naming submenu, persistent custom names, Back handling, 9-second timeout, TvInputManager discovery attempt, TvView pass-through tune attempt, build workflow.
- Known limitation: physical HDMI switching and source-key interception are OEM/system-dependent and cannot be confirmed without the target TV.
- Build verification: not run; this environment lacks Android SDK/Gradle and outbound dependency downloads are unavailable.
- Next step: compile via Android Studio or GitHub Actions, install on the Acer TV, and verify whether TvInputManager exposes the HDMI pass-through inputs.
