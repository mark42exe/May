# Glass HDMI Input Switcher (Acer Android TV)

Standalone Android TV app prototype based on the supplied `Live TV input panel_ glass preview.html` design. The app keeps the frosted-glass sidebar, bright selected row, slide animations, HDMI rename submenu, D-pad handling, Back behavior, and 9-second idle timeout.

## Important real-TV limitation

A regular third-party Android TV app cannot universally replace the OEM input/source panel or guarantee switching the physical HDMI ports. On many TVs, `TvInputManager` and pass-through `TvView` access is restricted to privileged/system apps. This app detects available pass-through inputs and attempts to tune them where the firmware allows it. If the Acer firmware blocks access, the interface remains usable but real HDMI switching is not available to this APK. The HDMI1/2/3 rows shown when the system hides its inputs are explicitly non-switchable placeholders, not claims that the ports were detected.

The app is a foreground panel, not an always-on-top system overlay. A third-party app also cannot intercept the hardware Source button on every Acer remote. It must be launched from the Android TV app launcher unless Acer offers a remote-button remapping facility.

## Build

Requirements: Android Studio with Android SDK Platform 35 and JDK 17, or a CI environment with Gradle 8.9.

1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s), or run `gradle assembleDebug` from this folder.
4. Output: `app/build/outputs/apk/debug/app-debug.apk`.

A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`. Upload this project to a GitHub repository and run the workflow; it will produce the APK as a downloadable workflow artifact.

## Controls

- D-pad Up/Down: move through inputs.
- OK/Enter: choose the selected row.
- Hold OK on an HDMI row: open its naming submenu.
- Right: open the HDMI naming submenu.
- Left: close the submenu.
- Back: dismiss the panel; Back from a launched TV input returns to the panel.
- The panel auto-hides after 9 seconds without interaction.

## Project status

Source project prepared. This environment does not have Android SDK/Gradle installed and cannot download build dependencies, so an APK has not been compiled or device-tested here. Use Android Studio or the included GitHub Actions workflow to compile it. Real HDMI switching must be tested on the exact Acer TV model/firmware.
