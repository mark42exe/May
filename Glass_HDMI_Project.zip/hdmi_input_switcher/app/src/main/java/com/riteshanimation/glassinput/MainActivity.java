package com.riteshanimation.glassinput;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.media.tv.TvContract;
import android.media.tv.TvInputInfo;
import android.media.tv.TvInputManager;
import android.media.tv.TvView;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

public class MainActivity extends Activity {
    private FrameLayout root;
    private TvView tvView;
    private WebView webView;
    private TvInputManager tvInputManager;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean centerLongPressed = false;
    private boolean tvMode = false;
    private final Runnable longPressAction = new Runnable() {
        @Override public void run() {
            centerLongPressed = true;
            runJs("window.showNameMenuForCurrent && window.showNameMenuForCurrent();");
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        try { tvInputManager = (TvInputManager) getSystemService(TV_INPUT_SERVICE); }
        catch (Exception ignored) { tvInputManager = null; }

        root = new FrameLayout(this);
        root.setFocusable(true);
        root.setFocusableInTouchMode(true);
        root.setBackgroundColor(Color.BLACK);

        tvView = new TvView(this);
        tvView.setBackgroundColor(Color.BLACK);
        tvView.setVisibility(View.GONE);
        root.addView(tvView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.TRANSPARENT);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(false);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        root.addView(webView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        webView.loadUrl("file:///android_asset/index.html");
        webView.requestFocus();

        tvView.setCallback(new TvView.TvInputCallback() {
            @Override public void onConnectionFailed(String inputId) {
                runOnUiThread(() -> {
                    if (tvMode) {
                        tvMode = false;
                        tvView.setVisibility(View.GONE);
                        webView.setVisibility(View.VISIBLE);
                        runJs("window.refreshInputs && window.refreshInputs();");
                        Toast.makeText(MainActivity.this, "Acer TV input connection failed. HDMI switching may require system access.", Toast.LENGTH_LONG).show();
                    }
                });
            }
            @Override public void onDisconnected(String inputId) {
                runOnUiThread(() -> {
                    if (tvMode) {
                        tvMode = false;
                        tvView.setVisibility(View.GONE);
                        webView.setVisibility(View.VISIBLE);
                        Toast.makeText(MainActivity.this, "Input disconnected.", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }, handler);
    }

    private void runJs(String js) {
        if (webView != null) runOnUiThread(() -> webView.evaluateJavascript(js, null));
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_DPAD_CENTER || event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                if (event.getRepeatCount() == 0) {
                    centerLongPressed = false;
                    handler.removeCallbacks(longPressAction);
                    handler.postDelayed(longPressAction, 560);
                }
                return true;
            } else if (event.getAction() == KeyEvent.ACTION_UP) {
                handler.removeCallbacks(longPressAction);
                if (!centerLongPressed) runJs("window.selectCurrent && window.selectCurrent();");
                centerLongPressed = false;
                return true;
            }
        }
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
            handler.removeCallbacks(longPressAction);
            if (tvMode) {
                tvMode = false;
                tvView.setVisibility(View.GONE);
                webView.setVisibility(View.VISIBLE);
                runJs("window.refreshInputs && window.refreshInputs();");
                webView.requestFocus();
            } else {
                runJs("window.handleBack && window.handleBack();");
            }
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override public void onBackPressed() {
        if (tvMode) {
            tvMode = false;
            tvView.setVisibility(View.GONE);
            webView.setVisibility(View.VISIBLE);
            runJs("window.refreshInputs && window.refreshInputs();");
        } else {
            runJs("window.handleBack && window.handleBack();");
        }
    }

    private class AndroidBridge {
        @JavascriptInterface public String getSourcesJson() {
            JSONArray result = new JSONArray();
            JSONObject home = new JSONObject();
            try {
                home.put("id", "home"); home.put("label", "Google TV Home"); home.put("kind", "home");
                home.put("home", true); home.put("switchable", true); result.put(home);
            } catch (Exception ignored) {}

            boolean foundPassthrough = false;
            if (tvInputManager != null) {
                try {
                    List<TvInputInfo> inputs = tvInputManager.getTvInputList();
                    for (TvInputInfo info : inputs) {
                        boolean passthrough;
                        try { passthrough = info.isPassthroughInput(); } catch (Exception e) { passthrough = false; }
                        CharSequence rawLabel;
                        try { rawLabel = info.loadLabel(MainActivity.this); } catch (Exception e) { rawLabel = null; }
                        String label = rawLabel == null ? info.getId() : rawLabel.toString();
                        if (label == null || label.trim().isEmpty()) label = "TV Input";
                        String lower = label.toLowerCase();
                        String kind = lower.contains("hdmi") || lower.contains("displayport") ? "hdmi" : (lower.contains("av") ? "av" : "tv");
                        if (passthrough) foundPassthrough = true;
                        JSONObject item = new JSONObject();
                        item.put("id", info.getId()); item.put("label", label); item.put("kind", kind);
                        item.put("home", false); item.put("switchable", passthrough);
                        result.put(item);
                    }
                } catch (SecurityException denied) {
                    // ACCESS_TV_INPUT is commonly restricted to system/OEM apps. Keep the UI usable.
                } catch (Exception ignored) {}
            }
            if (!foundPassthrough) {
                addFallback(result, "fallback_atv", "ATV", "tv");
                addFallback(result, "fallback_cable", "CABLE", "tv");
                addFallback(result, "fallback_antenna", "ANTENNA", "tv");
                addFallback(result, "fallback_hdmi1", "HDMI1", "hdmi");
                addFallback(result, "fallback_hdmi2", "HDMI2", "hdmi");
                addFallback(result, "fallback_hdmi3", "HDMI3", "hdmi");
                addFallback(result, "fallback_av", "AV", "av");
            }
            return result.toString();
        }

        private void addFallback(JSONArray result, String id, String label, String kind) {
            try {
                JSONObject item = new JSONObject(); item.put("id", id); item.put("label", label);
                item.put("kind", kind); item.put("home", false); item.put("switchable", false); result.put(item);
            } catch (Exception ignored) {}
        }

        @JavascriptInterface public boolean switchInput(String inputId) {
            if (inputId == null || inputId.startsWith("fallback_")) return false;
            if ("home".equals(inputId)) { openHome(); return true; }
            try {
                Uri uri = TvContract.buildChannelUriForPassthroughInput(inputId);
                runOnUiThread(() -> {
                    try {
                        tvMode = true;
                        tvView.setVisibility(View.VISIBLE);
                        webView.setVisibility(View.GONE);
                        tvView.tune(inputId, uri);
                    } catch (Exception e) {
                        tvMode = false; tvView.setVisibility(View.GONE); webView.setVisibility(View.VISIBLE);
                        Toast.makeText(MainActivity.this, "This Acer TV does not allow app-level HDMI switching.", Toast.LENGTH_LONG).show();
                    }
                });
                return true;
            } catch (SecurityException | IllegalArgumentException e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "HDMI switching requires Acer system access on this TV.", Toast.LENGTH_LONG).show());
                return false;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface public void openHome() {
            runOnUiThread(() -> {
                try {
                    Intent home = new Intent(Intent.ACTION_MAIN);
                    home.addCategory(Intent.CATEGORY_HOME);
                    home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(home);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "No home launcher was found.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface public void setInputName(String inputId, String name) {
            if (inputId == null || name == null) return;
            getSharedPreferences("input_names", MODE_PRIVATE).edit().putString(inputId, name).apply();
        }
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (webView != null) { webView.removeJavascriptInterface("AndroidBridge"); webView.destroy(); }
        super.onDestroy();
    }
}
